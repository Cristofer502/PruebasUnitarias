package com.PruebasUnitaras.MockitoJunit.repository;

import com.PruebasUnitaras.MockitoJunit.model.User;

public interface UserRepository extends CrudRepository<User, Long> {
}
