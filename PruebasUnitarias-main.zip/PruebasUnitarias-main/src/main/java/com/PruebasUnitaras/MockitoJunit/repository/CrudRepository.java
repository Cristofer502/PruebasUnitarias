package com.PruebasUnitaras.MockitoJunit.repository;

public interface CrudRepository<T, T1> {
}
